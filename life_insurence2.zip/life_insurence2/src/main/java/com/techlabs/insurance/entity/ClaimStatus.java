package com.techlabs.insurance.entity;

public enum ClaimStatus {
  PENDING,
  APPROVED,
  REJECT;
}
