package com.techlabs.insurance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifeInsurenceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LifeInsurenceApplication.class, args);
	}

}
