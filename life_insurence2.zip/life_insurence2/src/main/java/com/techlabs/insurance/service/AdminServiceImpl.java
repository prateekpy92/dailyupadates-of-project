package com.techlabs.insurance.service;

import java.util.ArrayList;


import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.apache.catalina.mapper.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.techlabs.insurance.dto.AddEmployeeDto;
import com.techlabs.insurance.dto.AdminGetDto;
import com.techlabs.insurance.dto.AdminPostDto;
//import com.techlabs.insurance.dto.ClaimApproveDto;
import com.techlabs.insurance.dto.JwtAuthResponse;
import com.techlabs.insurance.dto.LoginDto;
//import com.techlabs.insurance.dto.Message;
import com.techlabs.insurance.entity.Admin;
import com.techlabs.insurance.entity.Agent;
import com.techlabs.insurance.entity.Claim;
import com.techlabs.insurance.entity.ClaimStatus;
import com.techlabs.insurance.entity.Employee;
import com.techlabs.insurance.entity.InsurancePolicy;
import com.techlabs.insurance.entity.Login;
import com.techlabs.insurance.entity.PolicyStatus;
import com.techlabs.insurance.entity.Role;
import com.techlabs.insurance.entity.UserDetails;
import com.techlabs.insurance.exception.InsuranceException;
//import com.techlabs.insurance.mapper.EmployeeMapper;
//import com.techlabs.insurance.mapper.InsuranceSchemeMapper;
import com.techlabs.insurance.mapper.UserMapper;
import com.techlabs.insurance.repository.AdminRepository;
import com.techlabs.insurance.repository.AgentRepository;
import com.techlabs.insurance.repository.CustomerRepository;
import com.techlabs.insurance.repository.EmployeeRepository;
import com.techlabs.insurance.repository.LoginRepository;
import com.techlabs.insurance.repository.PolicyRepository;
import com.techlabs.insurance.repository.RoleRepository;
import com.techlabs.insurance.security.JwtTokenProvider;

@Service
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	private AdminRepository adminRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
    private PasswordEncoder passwordEncoder;
	@Autowired
    private JwtTokenProvider jwtTokenProvider;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private AgentRepository agentRepository;
    @Autowired
    private LoginRepository loginRepository;
    @Autowired
    private PolicyRepository policyRepository;
    
    

	@Override
	public JwtAuthResponse adminLogin(LoginDto loginDto) {
		 try{
			 			 
			 JwtAuthResponse response = new JwtAuthResponse();
				System.out.println("login dto value is +"+loginDto);
				Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginDto.getUserName(), loginDto.getPassword()));
				SecurityContextHolder.getContext().setAuthentication(authentication);
				String token = jwtTokenProvider.generateToken(authentication);
				response.setTokenType("Bearer");
				response.setAccessToken(token);
				response.setUsername(authentication.getName());
				System.out.println("authentication is "+authentication);
				response.setRoleType(authentication.getAuthorities().iterator().next().toString());
				
				if(!response.getRoleType().equals(loginDto.getRoleType()))
				{
					throw new InsuranceException("Admin not exist!");
				}
				return response;
				
			}
			catch (BadCredentialsException e)
			{
				throw new InsuranceException("Bad Request");
			}
			
		}
	


	@Override
	public AdminGetDto addAdmin(AdminPostDto adminPostDto) {
		
		List<Login> admindb = loginRepository.findAll();
		System.out.println("addadmin dto value "+adminPostDto);
		
		for(Login log:admindb)
		{
			if(adminPostDto.getUsername().equals(log.getUsername()))
			{
				throw new InsuranceException("username already used!");
			}
		}
		
		
		
		 UserDetails details = UserMapper.adminPostDtoToUserDetails(adminPostDto);
			

	        Login login = new Login();
			login.setUsername(adminPostDto.getUsername());
			login.setPassword(passwordEncoder.encode(adminPostDto.getPassword()));

			Set<Role> role = new HashSet<>();
	      
			  Role userRole = roleRepository.findByRolename("ROLE_ADMIN").get(); 
			  role.add(userRole); 
			  login.setRoles(role);
			  Admin admin = new Admin();
			  
		      admin.setUserDetails(details);
		      admin.setLogin(login);

	          adminRepository.save(admin);
			  return UserMapper.userToUserGetDto(details);
		
		
	}

	@Override
	public Page<AdminGetDto> getAllAdmin(Pageable pageable) {
		Page<Admin> admins = adminRepository.findByIsactiveTrue(pageable);
		Page<AdminGetDto> adminList = admins.map(user -> UserMapper.userToUserGetDto(user.getUserDetails()));

	    if (adminList.isEmpty()) {
	        throw new InsuranceException("No Admin found");
	    }

	    
	    return adminList;
	}
	
	
	@Override
	public String validateuser(String token) {
		JwtTokenProvider jwtprovider = new JwtTokenProvider();
		String role = jwtprovider.getRole(token).toString();
		
		return role;
	}



	@Override
	public List<Agent> getAgentClaims() {
		List<Agent> agents=agentRepository.findAll();
		List<Agent>agentDb=new ArrayList<>();
		for(Agent agent:agents) {
			List<Claim> claims=agent.getClaims();
			boolean flag =false;
			for(Claim claim:claims) {
				if(claim.getStatus().equals("PENDING")) {
					flag=true;
				}
			}
			if(flag)
			agentDb.add(agent);
		}	
//	)
		return agentDb;
	}
	
	
	@Override
	public List<InsurancePolicy> getpolicyClaims() {
		
		List<InsurancePolicy>policies=policyRepository.findAll();
		
		List<InsurancePolicy>policyDb=new ArrayList<>();
		
		for(InsurancePolicy insurancePolicy:policies) {
			if(insurancePolicy.getClaims()!=null && (insurancePolicy.getStatus()==PolicyStatus.DROP || insurancePolicy.getStatus()==PolicyStatus.COMPLETE)) {
				
				policyDb.add(insurancePolicy);
			
			
			}
			
		}
		
		return policyDb;
		
	}
	
	
	
	
}
