package com.techlabs.insurance.entity;

public enum CommissionType {
	REGISTRATION,INSTALMENT

}
