package com.techlabs.insurance.config;

import java.util.List;

import org.springframework.context.annotation.Bean;


import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.techlabs.insurance.security.JwtAuthenticationEntryPoint;
import com.techlabs.insurance.security.JwtAuthenticationFilter;

@EnableMethodSecurity
@Configuration 
public class SecurityConfig {
	
	private UserDetailsService userDetailsService;
	private JwtAuthenticationEntryPoint authenticationEntryPoint;
	private JwtAuthenticationFilter authenticationFilter;
	
	
	public SecurityConfig(UserDetailsService userDetailsService, JwtAuthenticationEntryPoint authenticationEntryPoint,
			JwtAuthenticationFilter authenticationFilter) {
		this.userDetailsService = userDetailsService;
		this.authenticationEntryPoint = authenticationEntryPoint;
		this.authenticationFilter = authenticationFilter;
	}
	
	@Bean
	public static PasswordEncoder passwordEncoder()
	{
		return new BCryptPasswordEncoder();
	}
	@Bean 
	public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration )throws Exception
	{
		return configuration.getAuthenticationManager();
	}
	
	
//	@Bean 
//	SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception
//	{
//        http.csrf(csrf -> csrf.disable())
//                .authorizeHttpRequests((authorize) ->
//                        authorize.requestMatchers(HttpMethod.GET, "/swagger-ui/", "/v3/api-docs/", "/v3/api-docs.yaml",
//  	                        "/swagger-resources/", "/swagger-ui.html", "/webjars/").permitAll()
//                        .requestMatchers(HttpMethod.GET, "/insuranceapp/**").permitAll()
//                                .requestMatchers(HttpMethod.POST, "/insuranceapp/**").permitAll()
//                                
//                                .requestMatchers("/insuranceapp/**").permitAll()
//                                
//                                .anyRequest().authenticated()
//                ).exceptionHandling(exception -> exception
//                        .authenticationEntryPoint(authenticationEntryPoint)
//        ).sessionManagement(session -> session
//                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
//        );
//				
//		http.addFilterBefore(authenticationFilter, UsernamePasswordAuthenticationFilter.class);
//			
//		return http.build();
//	
//	}

	
	  @Bean
	    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
	        http.csrf(cs -> cs.disable())
	            .cors(cors -> cors.configurationSource(corsConfigurationSource())) // Enable CORS
	            .authorizeHttpRequests(authz -> authz
	            	.requestMatchers(HttpMethod.GET, "/swagger-ui/", "/v3/api-docs/", "/v3/api-docs.yaml",
	            	                        "/swagger-resources/", "/swagger-ui.html", "/webjars/").permitAll()
	                .requestMatchers(HttpMethod.POST, "/insuranceapp/**").permitAll() // Allow unauthenticated access to authentication endpoints
	                .requestMatchers(HttpMethod.POST, "/insuranceapp/**").hasRole("ADMIN")
//	                .requestMatchers(HttpMethod.POST, "/api/accounts/**").hasRole("ADMIN")
	                .requestMatchers(HttpMethod.GET, "/insuranceapp/**").hasRole("ADMIN")
	                .requestMatchers(HttpMethod.POST, "/insuranceapp/**").hasRole("CUSTOMER")
	             // Correct endpoint paths
	                .requestMatchers(HttpMethod.GET, "/insuranceapp/**").hasRole("CUSTOMER")
	                
	                .requestMatchers(HttpMethod.POST, "insuranceapp/allAgents/**").hasRole("EMPLOYEE")
	// Adjusted to match your controller path
	                .requestMatchers(HttpMethod.GET, "/insuranceapp/**").hasRole("EMPLOYEE")
	                .requestMatchers(HttpMethod.GET, "/insuranceapp/**").permitAll()
	                .requestMatchers(HttpMethod.GET, "/insuranceapp/**").permitAll()
	                .requestMatchers(HttpMethod.GET, "/insuranceapp/**").hasRole("AGENT")
	                .requestMatchers(HttpMethod.POST, "/insuranceapp/**").hasRole("AGENT")
	                .requestMatchers(HttpMethod.PATCH, "/insuranceapp/**").hasRole("ADMIN") 
	                .anyRequest().authenticated()
	            )
	            .exceptionHandling(exception -> exception
	                .authenticationEntryPoint(authenticationEntryPoint)
	            )
	            .sessionManagement(session -> session
	                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
	            );

	        http.addFilterBefore(authenticationFilter, UsernamePasswordAuthenticationFilter.class);
	        return http.build();
	    }
	  @Bean
	    public CorsConfigurationSource corsConfigurationSource() {
	        CorsConfiguration configuration = new CorsConfiguration();
	        configuration.setAllowedOrigins(List.of("http://localhost:3000")); // Allow your frontend origin
	        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS","PATCH"));
	        configuration.setAllowedHeaders(List.of("Authorization", "Content-Type"));
	        configuration.setAllowCredentials(true); // Allow credentials if needed
	        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
	        source.registerCorsConfiguration("/**", configuration);
	        return source;
	    }

	  @Bean
	    public WebSecurityCustomizer webSecurityCustomizer() {
	        return (web) -> web.ignoring()
	            .requestMatchers("/swagger-ui/**", "/v3/api-docs/**");
	    }
	}


