package com.techlabs.insurance.entity;

public enum DocumentStatus {
	
	APPROVED,
	PENDING,
	REJECTED

}
