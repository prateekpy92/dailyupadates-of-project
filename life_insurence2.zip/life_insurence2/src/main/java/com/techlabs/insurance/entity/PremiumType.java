package com.techlabs.insurance.entity;

public enum PremiumType {
	MONTHLY,
    QUARTERLY,
    HALF_YEARLY,
    YEARLY;
}
