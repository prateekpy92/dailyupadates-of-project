package com.techlabs.insurance.entity;

public enum QuestionStatus {
    PENDING,
    SOLVED
}