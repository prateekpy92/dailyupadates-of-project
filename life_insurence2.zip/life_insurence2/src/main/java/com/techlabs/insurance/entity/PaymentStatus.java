package com.techlabs.insurance.entity;

public enum PaymentStatus {
	PAID,UNPAID

}
