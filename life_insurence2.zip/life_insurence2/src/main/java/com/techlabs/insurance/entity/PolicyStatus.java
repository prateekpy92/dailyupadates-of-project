package com.techlabs.insurance.entity;

public enum PolicyStatus {
	PENDING,ACTIVE,REJECT,COMPLETE,DROP,CLAIMED
}
