package com.techlabs.insurance.service;

import org.springframework.data.domain.Page;


import org.springframework.data.domain.Pageable;

import com.techlabs.insurance.dto.AccountDto;
import com.techlabs.insurance.dto.AgentClaimDto;
import com.techlabs.insurance.dto.AgentDto;
import com.techlabs.insurance.dto.AgentGetDto;

import com.techlabs.insurance.dto.JwtAuthResponse;
import com.techlabs.insurance.dto.LoginDto;

import com.techlabs.insurance.entity.Agent;

public interface AgentService {
	
	JwtAuthResponse agentLogin(LoginDto logindto);
	AgentGetDto getAgentByUsername(String username);
	
	Page<AgentGetDto> getAllAgents(Pageable pageable);
	
	Agent getAgentDetail(String username);
	
	Page<AccountDto> getAllAccounts(Pageable pageable, long id);
}
