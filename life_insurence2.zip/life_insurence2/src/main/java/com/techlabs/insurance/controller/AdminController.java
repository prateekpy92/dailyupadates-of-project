package com.techlabs.insurance.controller;

import java.util.List;




//import org.modelmapper.internal.bytebuddy.implementation.bind.annotation.Default;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.techlabs.insurance.dto.AddEmployeeDto;

import com.techlabs.insurance.dto.AdminGetDto;
import com.techlabs.insurance.dto.AdminPostDto;

import com.techlabs.insurance.dto.JwtAuthResponse;
import com.techlabs.insurance.dto.LoginDto;

import com.techlabs.insurance.entity.Agent;
import com.techlabs.insurance.entity.InsurancePolicy;
import com.techlabs.insurance.repository.InsurancePlanRepository;
import com.techlabs.insurance.repository.InsuranceSchemeRepository;
import com.techlabs.insurance.service.AdminService;


@RequestMapping("/insuranceapp")
@RestController
public class AdminController {
	@Autowired
	private AdminService adminService;
	
	
	@PostMapping("/admin")
	public  ResponseEntity<AdminGetDto> addAdmin(@RequestBody AdminPostDto adminPostDto)
	{
		System.out.println("admin dto "+adminPostDto);
		AdminGetDto admin = adminService.addAdmin(adminPostDto);
		return new ResponseEntity<>(admin, HttpStatus.OK);
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/admin")
	public ResponseEntity<Page<AdminGetDto>>getAllAdmin(@RequestParam int pageNumber,@RequestParam int pageSize)
	{
		System.out.println("pagenumber,pagesize are "+pageNumber+" ,"+pageSize);
		Pageable pageable = PageRequest.of(pageNumber,pageSize);
		Page<AdminGetDto> admins = adminService.getAllAdmin(pageable);
		
		
		return new ResponseEntity<>(admins, HttpStatus.OK);
	}
	
	
	
	@GetMapping("/agentClaims")
	public ResponseEntity<List<Agent>>agentClaims(){
		
		List<Agent> agents=adminService.getAgentClaims();
		
		return ResponseEntity.ok(agents);
		
	}
	
	@GetMapping("/policyClaims")
	public ResponseEntity<List<InsurancePolicy>>policyClaims(){
		
		List<InsurancePolicy> agents=adminService.getpolicyClaims();
		
		return ResponseEntity.ok(agents);
		
	}
	
	
	
	
	
	
	
	

}
