package com.techlabs.insurance.controller;


import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.techlabs.insurance.dto.AccountDto;
import com.techlabs.insurance.dto.AgentClaimDto;
import com.techlabs.insurance.dto.AgentDto;
import com.techlabs.insurance.dto.AgentGetDto;


import com.techlabs.insurance.entity.Agent;
import com.techlabs.insurance.service.AgentService;



@RestController
@RequestMapping("/insuranceapp")
public class AgentController {

	
	
	@Autowired
	private AgentService agentService;

//	@PostMapping("/addagent")
//	//@PreAuthorize("hasRole('ADMIN')")
//	ResponseEntity<Message> addAgent( @RequestBody AgentDto agentDto) {
//        System.out.println("agent dto>>"+agentDto);
//		Message message = agentService.addAgent(agentDto);
//		
//
//		return ResponseEntity.ok(message);
//
//	}
	
	@GetMapping("/agent")
	//@PreAuthorize("hasRole('AGENT')")
	ResponseEntity<AgentGetDto> getAgentByUsername( @RequestParam String username) {

		 AgentGetDto agentGetDto= agentService.getAgentByUsername(username);

		return ResponseEntity.ok(agentGetDto);
     }
	
	
	@GetMapping("/allAgents")
	//@PreAuthorize("hasRole('EMPLOYEE')")
	ResponseEntity<Page<AgentGetDto>>getAllAgents(@RequestParam int pageNumber, @RequestParam int pageSize) {
		
		 Pageable pageable=PageRequest.of(pageNumber, pageSize); 

		 Page<AgentGetDto>page= agentService.getAllAgents(pageable);
		 HttpHeaders headers = new HttpHeaders();
		 headers.add("Agent-Count", String.valueOf(page.getTotalElements()));
		 return ResponseEntity.ok().headers(headers).body(page);	
	}
	
	
	
	
	

	@GetMapping("/agentDetail")
	ResponseEntity<Agent> getAgentDetails(@RequestParam String username){
		Agent agent=agentService.getAgentDetail(username);
		return ResponseEntity.ok(agent);
	}
	
	
	
	
	@GetMapping("/allpolicies")
	//@PreAuthorize("hasRole('AGENT')")
	ResponseEntity<Page<AccountDto>>getAllAccount(@RequestParam int pageNumber, @RequestParam int pageSize,@RequestParam long id) {
		
		 Pageable pageable=PageRequest.of(pageNumber, pageSize); 

		 Page<AccountDto>acc= agentService.getAllAccounts(pageable,id);
		 HttpHeaders headers = new HttpHeaders();
		 headers.add("customer-account", String.valueOf(acc.getTotalElements()));
		 return ResponseEntity.ok().headers(headers).body(acc);
	

	}


}